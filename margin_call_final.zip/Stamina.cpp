﻿#include "Stamina.h"

Stamina::Stamina(int startMax)
    : currentStamina(startMax), maxStamina(startMax) {}

int Stamina::getCurrent() const {
    return currentStamina;
}

int Stamina::getMax() const {
    return maxStamina;
}

bool Stamina::consume(int amount) {
    if (currentStamina >= amount) {
        currentStamina -= amount;
        return true;
    }

    return false;
}

void Stamina::refill() {
    refill(50);
}

void Stamina::refill(int amount) {
    currentStamina += amount;

    if (currentStamina > maxStamina) {
        currentStamina = maxStamina;
    }
}

void Stamina::increaseMax(int amount) {
    maxStamina += amount;
}
