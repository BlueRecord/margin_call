﻿#define NOMINMAX
#pragma execution_character_set("utf-8")

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <string>//모니터 관련 UI 때문에 포함시켰습니다. 밑에 monitor_Line함수에서 자세하게 설명했습니다
#include <windows.h>
#include <conio.h> //아무 키 입력 시 넘어가는 것을 수월하게 하기 위해 추가한 파일입니다

#include "Money.h"
#include "Stamina.h"
#include "Market.h"
#include "Store.h"
#include "Portfolio.h"

using namespace std;

const int MONITOR_WIDTH = 54;
const string INDENT = "        ";

const long long TARGET_MONEY = 50000; // 목표 자산은 5000만원으로 동일하게 설정하였고
const int MAX_DAY = 25;          // 제한 일수를 25일로 만들어서 게임 오버 기준을 세웠습니다


//UI 제작 시 깔끔하게 하기 위해 화면에 있는 글자를 다 지우는 용도입니다.
void clearScreen() {
    system("cls");
}

void waitKey() {
    cout << "\n아무 키나 누르면 계속합니다...";
    _getch();      //위에서 포함시킨 <conio.h>에 있는 함수입니다
}

int inputNumber() {
    int num;

    while (true) {
        cin >> num;

        if (!cin.fail()) {
            return num;
        }

        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "숫자만 입력하세요 >> ";
    }
}

/* 모니터 관련 UI를 제작하는데 한글이랑 영어가 줄이 조금씩 안맞아 아스키 코드 그림이
 뒤틀리는 현상이 발생하여 줄 맞춤 함수를 사용했습니다, 저도 만들면서 완벽하게
 이해하지는 못했지만 질문하시면 설명해드리겠습니다*/
int getTextWidth(const string& text) {
    int width = 0;

    for (size_t i = 0; i < text.size();) {
        unsigned char c = static_cast<unsigned char>(text[i]);

        if (c < 128) {
            width += 1;
            i += 1;
        }
        else {
            width += 2;

            if ((c & 0xE0) == 0xC0) i += 2;
            else if ((c & 0xF0) == 0xE0) i += 3;
            else if ((c & 0xF8) == 0xF0) i += 4;
            else i += 1;
        }
    }

    return width;
}

//이것도 마찬가지로 줄 맞춤 함수입니다
void monitorLine(const string& text = "") {
    cout << INDENT << "| " << text;

    int spaces = MONITOR_WIDTH - getTextWidth(text);
    if (spaces < 0) spaces = 0;

    cout << string(spaces, ' ') << " |\n";
}

void monitorTop() {
    cout << "\n";
    cout << INDENT << "+" << string(MONITOR_WIDTH + 2, '-') << "+\n";
    monitorLine("MARGIN CALL");
    cout << INDENT << "+" << string(MONITOR_WIDTH + 2, '-') << "+\n";
    monitorLine();
    monitorLine();
}

void monitorBottom() {
    monitorLine();
    cout << INDENT << "+" << string(MONITOR_WIDTH + 2, '-') << "+\n";
    cout << INDENT << "              |                    |\n";
    cout << INDENT << "              |____________________|\n";
    cout << INDENT << "            /________________________\\\n\n";
}

void monitorTitle(const string& title) {
    monitorTop();
    monitorLine("> " + title);
    monitorLine();
}

void showStory() {
    clearScreen();

    monitorTitle("STORY");

    monitorLine("주인공은 낮에는 물류센터 알바를 하고");
    Sleep(1200);
    monitorLine("밤에는 좁은 자취방에서 낡은 모니터를 봅니다.");
    Sleep(1200);
    monitorLine("그는 주식 차트를 공부하는 청년입니다.");
    Sleep(1200);
    monitorLine();
    monitorLine("가진 것은 오직 부모님이 남겨주신 2500만원");
    Sleep(1200);
    monitorLine("그리고 가난의 굴레에서 벗어나겠다는 독기뿐입니다.");
    Sleep(1200);
    monitorLine();
    monitorLine("목표는 돈과 스테미나를 관리하며 25일 안에");
    Sleep(1200);
    monitorLine("자산을 두배인 5000만원까지 불리는 것입니다.");

    monitorBottom();

    waitKey();
}

void showHowToPlay() {
    clearScreen();

    monitorTitle("SYSTEM GUIDE");

    monitorLine("1. 주식 시장 확인:");
    monitorLine("   현재 주식 가격을 확인합니다.");

    monitorLine("2. 주식 매수:");
    monitorLine("   돈을 사용해 주식을 구매합니다.");
    monitorLine("   거래할 때마다 스테미나가 줄어듭니다.");

    monitorLine("3. 주식 매도:");
    monitorLine("   보유한 주식을 팔아 돈을 얻습니다.");

    monitorLine("4. 상점 이용:");
    monitorLine("   아이템으로 스테미나를 관리합니다.");

    monitorLine("5. 내 자산 확인:");
    monitorLine("   돈, 스테미나, 보유 주식을 확인합니다.");

    monitorLine("6. 하루 넘기기:");
    monitorLine("   주식 가격이 변동됩니다.");

    monitorLine("목표: 25일 안에 자산을 5000만원까지 불리기");

    monitorBottom();

    waitKey();
}

void showMainMenu(int day) {
    monitorTitle("MAIN MENU");
    
    int remainDay = MAX_DAY - day;

    monitorLine(to_string(day) + "일차 - " + to_string(MAX_DAY) + "일차까지 앞으로 " + to_string(remainDay) + "일 -");
    monitorLine();
    
    monitorLine("1. 주식 시장 확인");
    monitorLine("2. 주식 매수");
    monitorLine("3. 주식 매도");
    monitorLine("4. 상점 이용");
    monitorLine("5. 내 자산 확인");
    monitorLine("6. 하루 넘기기");
    monitorLine("0. 모니터 끄기");

    monitorBottom();

    cout << "선택 >> ";
}

void printStockList(Market& market) {
    for (int i = 0; i < market.getStockCount(); i++) {
        string line = to_string(i+1) + ". " + market.getName(i)
            + " : $" + to_string(market.getPrice(i));

        monitorLine(line);
    }
}

void showMarketScreen(Market& market) {
    monitorTitle("MARKET VIEW");

    monitorLine("현재 접속 화면: 주식 시장");
    monitorLine();
    printStockList(market);

    monitorBottom();
}

void showBuyScreen(Market& market) {
    monitorTitle("BUY STOCK");

    monitorLine("매수할 주식을 선택하세요.");
    monitorLine();
    printStockList(market);
    monitorLine();
    monitorLine("0. 나가기");

    monitorBottom();

    cout << "매수할 주식 번호 >> ";
}

void showSellScreen(Market& market) {
    monitorTitle("SELL STOCK");

    monitorLine("매도할 주식을 선택하세요.");
    monitorLine();
    printStockList(market);
    monitorLine();
    monitorLine("0. 나가기");

    monitorBottom();

    cout << "매도할 주식 번호 >> ";
}

void showStoreScreen() {
    monitorTitle("ITEM STORE");

    monitorLine("1. 피로회복제  ($200)");
    monitorLine("   스테미나 +50 회복");
    monitorLine();

    monitorLine("2. 영양제      ($1000)");
    monitorLine("   최대 스테미나 +20 증가");
    monitorLine();

    monitorLine("0. 나가기");

    monitorBottom();

    cout << "구매할 아이템 번호 >> ";
}

void showResultStart(const string& title) {
    monitorTitle(title);
}

void showResultEnd() {
    monitorBottom();
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    srand(static_cast<unsigned int>(time(NULL)));

    Money myMoney(25000); //게임이 루즈해질거 같아서 시드머니를 기존 500만원에서 2500만원으로 올렸습니다
    Stamina myStamina(100);
    Market myMarket;
    Store myStore;
    Portfolio myPortfolio(myMoney, myStamina, myMarket, myStore);
    int day = 1;

    showStory();
    showHowToPlay();

    int choice;

    while (true) {
        clearScreen();

        showMainMenu(day);
        choice = inputNumber();

        clearScreen();

        if (choice == 0) {
            monitorTitle("SHUT DOWN");
            Sleep(2000);
            monitorLine("모니터 전원을 끕니다.");
            Sleep(2000);
            monitorLine("당신은 돈에 대한 집착을 버리고 자리에서 일어납니다.");
            Sleep(2000);
            monitorLine("HIDDEN ENDING: 열반에 이르는 자");
            monitorBottom();
            break;
        }
        else if (choice == 1) {
            showMarketScreen(myMarket);
            waitKey();
        }
        else if (choice == 2) {
            int stockNumber, index, qty;

            showBuyScreen(myMarket);
            stockNumber = inputNumber();

            if (stockNumber == 0) {
                continue;
            }

            index = stockNumber - 1;

            cout << "매수할 수량 >> ";
            qty = inputNumber();

            clearScreen();
            showResultStart("BUY RESULT");

            if (qty <= 0) {
                monitorLine("수량은 1 이상이어야 합니다.");
            }
            else {
                myPortfolio.buy(index, qty);
            }

            showResultEnd();
            waitKey();
        }
        else if (choice == 3) {
            int stockNumber, index, qty;

            showSellScreen(myMarket);
            stockNumber = inputNumber();

            if (stockNumber == 0) {
                continue;
            }

            index = stockNumber - 1;

            cout << "매도할 수량 >> ";
            qty = inputNumber();

            clearScreen();
            showResultStart("SELL RESULT");

            if (qty <= 0) {
                monitorLine("수량은 1 이상이어야 합니다.");
            }
            else {
                myPortfolio.sell(index, qty);
            }

            showResultEnd();
            waitKey();
        }
        else if (choice == 4) {
            int item;

            showStoreScreen();
            item = inputNumber();

            clearScreen();
            showResultStart("STORE RESULT");

            if (item == 1) {
                myStore.buyPotion(myMoney, myStamina);
            }
            else if (item == 2) {
                myStore.buyMaxUpgrade(myMoney, myStamina);
            }
            else if (item == 0) {
                monitorLine("상점에서 나갑니다.");
            }
            else {
                monitorLine("잘못된 아이템 번호입니다.");
            }

            showResultEnd();
            waitKey();
        }
        else if (choice == 5) {
            showResultStart("MY STATUS");
            myPortfolio.showStatus();
            showResultEnd();
            waitKey();
        }
        else if (choice == 6) {
            myMarket.updateStockPrice();
            day++;

            monitorTitle("NEXT DAY");
            monitorLine("하루가 지났습니다.");
            monitorLine("주가가 변동되었습니다.");
            monitorLine();
            monitorLine("새 주가는 1번 메뉴에서 확인하세요.");
            monitorBottom();

            waitKey();
        }
        else {
            monitorTitle("ERROR");
            monitorLine("잘못된 선택입니다.");
            monitorBottom();

            waitKey();
        }
        if (myMoney.getMoney() >= TARGET_MONEY) {
            clearScreen();
            monitorTitle("");
            Sleep(2000);
            monitorLine("목표 자산 5000만원을 달성했습니다");
            Sleep(2000);
            monitorLine("더러운 진흙에서조차 피어나는 연꽃처럼");
            Sleep(2000);
            monitorLine("당신은 이제 아름답게 피어날 일만 남았습니다");
            Sleep(2000);
            monitorLine("HAPPY ENDING: 연꽃 위에 선 자");
            monitorBottom();
            break;
        }

        if (day > MAX_DAY) {
            clearScreen();
            monitorTitle("");
            Sleep(2000);
            monitorLine("오지 않을 것 같던 25일의 밤이 왔습니다");
            Sleep(2000);
            monitorLine("목표 자산에 도달하지 못했습니다");
            Sleep(2000);
            monitorLine("당신은 영원히 욕망에 굴레에서 떠돌아다닐 것입니다");
            Sleep(2000);
            monitorLine("BAD ENDING: 아귀도에 떨어진 개미");
            Sleep(2000);
            monitorBottom();
            break;
        }
    }

    return 0;
}
