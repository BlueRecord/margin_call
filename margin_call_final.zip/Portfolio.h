﻿#pragma once

#include "Money.h"
#include "Stamina.h"
#include "Market.h"
#include "Store.h"

class Portfolio {
private:
    Money& money;
    Stamina& stamina;
    Market& market;
    Store& store;

    int myStocks[4];

public:
    Portfolio(Money& m, Stamina& s, Market& mar, Store& st);

    bool buy(int index, int qty);
    bool sell(int index, int qty);
    void showStatus() const;
};
