﻿#include "Portfolio.h"
#include <iostream>
#include <string>

using namespace std;

namespace {
    const int MONITOR_WIDTH = 54;
    const string INDENT = "        ";

    int getTextWidth(const string& text) {
        int width = 0;

        for (size_t i = 0; i < text.size();) {
            unsigned char c = static_cast<unsigned char>(text[i]);

            if (c < 128) {
                width += 1;
                i += 1;
            }
            else {
                width += 2;

                if ((c & 0xE0) == 0xC0) i += 2;
                else if ((c & 0xF0) == 0xE0) i += 3;
                else if ((c & 0xF8) == 0xF0) i += 4;
                else i += 1;
            }
        }

        return width;
    }

    void monitorLine(const string& text = "") {
        cout << INDENT << "| " << text;

        int spaces = MONITOR_WIDTH - getTextWidth(text);
        if (spaces < 0) spaces = 0;

        cout << string(spaces, ' ') << " |\n";
    }
}

Portfolio::Portfolio(Money& m, Stamina& s, Market& mar, Store& st)
    : money(m), stamina(s), market(mar), store(st)
{
    for (int i = 0; i < 4; i++) {
        myStocks[i] = 0;
    }
}

bool Portfolio::buy(int index, int qty) {
    if (index < 0 || index >= market.getStockCount()) {
        monitorLine("존재하지 않는 종목 번호입니다.");
        return false;
    }

    long long price = market.getPrice(index);
    long long totalCost = price * qty;

    if (money.getMoney() < totalCost) {
        monitorLine("잔액이 부족합니다.");
        monitorLine("필요 금액: $" + to_string(totalCost));
        monitorLine("현재 잔액: $" + to_string(money.getMoney()));
        return false;
    }

    if (!stamina.consume(10)) {
        monitorLine("스테미나가 부족하여 거래할 수 없습니다.");
        monitorLine("상점에서 회복 아이템을 구매하세요.");
        return false;
    }

    money.withdraw(totalCost);
    myStocks[index] += qty;

    monitorLine(market.getName(index) + " " + to_string(qty) + "주를 매수했습니다.");
    monitorLine("사용 금액: $" + to_string(totalCost));
    monitorLine("남은 잔액: $" + to_string(money.getMoney()));
    monitorLine("남은 스테미나: " + to_string(stamina.getCurrent()));

    return true;
}

bool Portfolio::sell(int index, int qty) {
    if (index < 0 || index >= market.getStockCount()) {
        monitorLine("존재하지 않는 종목 번호입니다.");
        return false;
    }

    if (myStocks[index] < qty) {
        monitorLine("보유 주식 수량이 부족합니다.");
        monitorLine("현재 보유: " + to_string(myStocks[index]) + "주");
        return false;
    }

    if (!stamina.consume(10)) {
        monitorLine("스테미나가 부족하여 거래할 수 없습니다.");
        monitorLine("상점에서 회복 아이템을 구매하세요.");
        return false;
    }

    long long price = market.getPrice(index);
    long long totalRevenue = price * qty;

    myStocks[index] -= qty;
    money.deposit(totalRevenue);

    monitorLine(market.getName(index) + " " + to_string(qty) + "주를 매도했습니다.");
    monitorLine("판매 금액: $" + to_string(totalRevenue));
    monitorLine("현재 잔액: $" + to_string(money.getMoney()));
    monitorLine("남은 스테미나: " + to_string(stamina.getCurrent()));

    return true;
}

void Portfolio::showStatus() const {
    monitorLine("현재 잔액: $" + to_string(money.getMoney()));
    monitorLine("현재 스테미나: " + to_string(stamina.getCurrent())
        + " / " + to_string(stamina.getMax()));
    monitorLine();

    monitorLine("보유 주식 현황");

    bool hasStock = false;

    for (int i = 0; i < market.getStockCount(); i++) {
        if (myStocks[i] > 0) {
            string line = "- " + market.getName(i)
                + ": " + to_string(myStocks[i])
                + "주 / 현재가 $" + to_string(market.getPrice(i));

            monitorLine(line);
            hasStock = true;
        }
    }

    if (!hasStock) {
        monitorLine("보유 중인 주식이 없습니다.");
    }
}
