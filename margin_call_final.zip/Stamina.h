﻿#pragma once

class Stamina {
private:
    int currentStamina;
    int maxStamina;

public:
    Stamina(int startMax);

    bool consume(int amount);
    void refill();
    void refill(int amount);
    void increaseMax(int amount);

    int getCurrent() const;
    int getMax() const;
};
