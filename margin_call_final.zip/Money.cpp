﻿#include "Money.h"

Money::Money(long long startMoney)
    : wallet(startMoney) {}

long long Money::getMoney() const {
    return wallet;
}

void Money::deposit(long long amount) {
    wallet += amount;
}

bool Money::withdraw(long long amount) {
    if (amount <= wallet) {
        wallet -= amount;
        return true;
    }

    return false;
}
