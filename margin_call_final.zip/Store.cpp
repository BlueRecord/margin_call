﻿#include "Store.h"
#include <iostream>
#include <string>

using namespace std;

namespace {
    const int MONITOR_WIDTH = 54;
    const string INDENT = "        ";

    int getTextWidth(const string& text) {
        int width = 0;

        for (size_t i = 0; i < text.size();) {
            unsigned char c = static_cast<unsigned char>(text[i]);

            if (c < 128) {
                width += 1;
                i += 1;
            }
            else {
                width += 2;

                if ((c & 0xE0) == 0xC0) i += 2;
                else if ((c & 0xF0) == 0xE0) i += 3;
                else if ((c & 0xF8) == 0xF0) i += 4;
                else i += 1;
            }
        }

        return width;
    }

    void monitorLine(const string& text = "") {
        cout << INDENT << "| " << text;

        int spaces = MONITOR_WIDTH - getTextWidth(text);
        if (spaces < 0) spaces = 0;

        cout << string(spaces, ' ') << " |\n";
    }
}

Store::Store() {}

void Store::displayStore() const {
    monitorLine("1. 피로회복제  ($200)");
    monitorLine("   스테미나 +50 회복");
    monitorLine();
    monitorLine("2. 영양제      ($1000)");
    monitorLine("   최대 스테미나 +20 증가");
}

void Store::buyPotion(Money& money, Stamina& stamina) {
    if (money.getMoney() < 200) {
        monitorLine("잔액이 부족합니다.");
        monitorLine("필요 금액: $200");
        monitorLine("현재 잔액: $" + to_string(money.getMoney()));
        return;
    }

    money.withdraw(200);
    stamina.refill(50);

    monitorLine("피로회복제를 구매했습니다.");
    monitorLine("스테미나가 50 회복되었습니다.");
    monitorLine("사용 금액: $200");
    monitorLine("남은 잔액: $" + to_string(money.getMoney()));
    monitorLine("현재 스테미나: " + to_string(stamina.getCurrent())
        + " / " + to_string(stamina.getMax()));
}

void Store::buyMaxUpgrade(Money& money, Stamina& stamina) {
    if (money.getMoney() < 1000) {
        monitorLine("잔액이 부족합니다.");
        monitorLine("필요 금액: $1000");
        monitorLine("현재 잔액: $" + to_string(money.getMoney()));
        return;
    }

    money.withdraw(1000);
    stamina.increaseMax(20);

    monitorLine("영양제를 구매했습니다.");
    monitorLine("최대 스테미나가 20 증가했습니다.");
    monitorLine("사용 금액: $1000");
    monitorLine("남은 잔액: $" + to_string(money.getMoney()));
    monitorLine("최대 스테미나: " + to_string(stamina.getMax()));
}
