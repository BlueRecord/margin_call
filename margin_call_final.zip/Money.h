﻿#pragma once

class Money {
private:
    long long wallet;

public:
    Money(long long startMoney);

    long long getMoney() const;
    void deposit(long long amount);
    bool withdraw(long long amount);
};
