﻿#include "Market.h"
#include <iostream>
#include <cstdlib>

using namespace std;

Market::Market() {
    stocks.push_back({ "Apple", 150 });
    stocks.push_back({ "Google", 2800 });
    stocks.push_back({ "Amazon", 3400 });
    stocks.push_back({ "Microsoft", 300 });
}

void Market::updateStockPrice() {
    for (auto& stock : stocks) {
        // 하루 주가 변동폭: -10% ~ +10%
        double rate = (rand() % 21 - 10) / 100.0;
        stock.price += static_cast<long long>(stock.price * rate);

        if (stock.price < 10) {
            stock.price = 10;
        }
    }
}

void Market::displayMarket() const {
    cout << "\nStock Market:\n";

    for (const auto& stock : stocks) {
        cout << stock.name << ": $" << stock.price << "\n";
    }

    cout << endl;
}

long long Market::getPrice(int index) const {
    if (index >= 0 && index < static_cast<int>(stocks.size())) {
        return stocks[index].price;
    }

    return -1;
}

string Market::getName(int index) const {
    if (index >= 0 && index < static_cast<int>(stocks.size())) {
        return stocks[index].name;
    }

    return "";
}

int Market::getStockCount() const {
    return static_cast<int>(stocks.size());
}
