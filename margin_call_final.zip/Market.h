﻿#pragma once

#include <vector>
#include <string>

using namespace std;

struct Stock {
    string name;
    long long price;
};

class Market {
private:
    vector<Stock> stocks;

public:
    Market();

    void updateStockPrice();
    void displayMarket() const;
    long long getPrice(int index) const;
    string getName(int index) const;
    int getStockCount() const;
};
