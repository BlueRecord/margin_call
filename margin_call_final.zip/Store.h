﻿#pragma once

#include "Money.h"
#include "Stamina.h"

class Store {
public:
    Store();

    void displayStore() const;
    void buyPotion(Money& money, Stamina& stamina);
    void buyMaxUpgrade(Money& money, Stamina& stamina);
};
